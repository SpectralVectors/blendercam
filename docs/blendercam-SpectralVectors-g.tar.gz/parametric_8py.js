var parametric_8py =
[
    [ "create_parametric_curve", "parametric_8py.html#a1b0e9636a5e2114b9a4685200d2bbbae", null ],
    [ "derive_bezier_handles", "parametric_8py.html#a02742565c1f1faf491c0d3d677dd33b6", null ],
    [ "make_edge_loops", "parametric_8py.html#a4da15b36d0d2946dca1fa698a15e8259", null ]
];