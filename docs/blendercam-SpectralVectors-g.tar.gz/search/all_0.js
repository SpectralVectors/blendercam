var searchData=
[
  ['3d_0',['An Open Source Solution for Artistic or Industrial CAM with Blender 3D',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md52',1,'']]]
];
