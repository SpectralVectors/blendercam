var searchData=
[
  ['getting_20started_0',['Getting started',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Getting_01started.html',1,'']]]
];
