var searchData=
[
  ['panel_20descriptions_0',['Blendercam Panel Descriptions',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Blendercam-Panel-Descriptions.html',1,'']]],
  ['pocket_20operations_1',['Profile and Pocket operations',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Profile_01and_01Pocket_01operations.html',1,'']]],
  ['profile_20and_20pocket_20operations_2',['Profile and Pocket operations',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Profile_01and_01Pocket_01operations.html',1,'']]]
];
