var searchData=
[
  ['👨‍🎓_20how_20to_20use_20wiki_0',['👨‍🎓 How to Use (Wiki)',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md55',1,'']]]
];
