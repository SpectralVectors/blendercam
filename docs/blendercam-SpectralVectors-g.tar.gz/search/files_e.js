var searchData=
[
  ['nc_2epy_0',['nc.py',['../nc_8py.html',1,'']]],
  ['nc_5fread_2epy_1',['nc_read.py',['../nc__read_8py.html',1,'']]],
  ['nclathe_5fread_2epy_2',['nclathe_read.py',['../nclathe__read_8py.html',1,'']]],
  ['num_5freader_2epy_3',['num_reader.py',['../num__reader_8py.html',1,'']]],
  ['numba_5fwrapper_2epy_4',['numba_wrapper.py',['../numba__wrapper_8py.html',1,'']]]
];
