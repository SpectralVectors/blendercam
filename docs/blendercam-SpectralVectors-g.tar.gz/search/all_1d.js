var searchData=
[
  ['👁️_20about_0',['👁️ About',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md54',1,'']]]
];
