var searchData=
[
  ['import_5fsettings_0',['import_settings',['../classcam_1_1ui_1_1import__settings.html',1,'cam::ui']]],
  ['iterator_1',['Iterator',['../classcam_1_1voronoi_1_1SiteList_1_1Iterator.html',1,'cam::voronoi::SiteList']]]
];
