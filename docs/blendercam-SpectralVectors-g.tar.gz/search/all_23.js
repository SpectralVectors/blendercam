var searchData=
[
  ['🤝_20contribute_0',['🤝 Contribute',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md60',1,'']]]
];
