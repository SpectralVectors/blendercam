var searchData=
[
  ['killpathsbackground_0',['KillPathsBackground',['../classcam_1_1ops_1_1KillPathsBackground.html',1,'cam::ops']]]
];
