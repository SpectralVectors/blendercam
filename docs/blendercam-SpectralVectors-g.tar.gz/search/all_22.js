var searchData=
[
  ['🤕_20disclaimer_0',['🤕 DISCLAIMER',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md65',1,'']]]
];
