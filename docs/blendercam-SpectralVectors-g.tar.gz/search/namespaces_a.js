var searchData=
[
  ['v_2dcarve_5f3mm_5f45deg_0',['v-carve_3mm_45deg',['../namespacev-carve__3mm__45deg.html',1,'']]],
  ['v_2dcarve_5f3mm_5f60deg_1',['v-carve_3mm_60deg',['../namespacev-carve__3mm__60deg.html',1,'']]],
  ['v_2dcarve_5f6mm_5f45deg_2',['v-carve_6mm_45deg',['../namespacev-carve__6mm__45deg.html',1,'']]],
  ['v_2dcarve_5f6mm_5f60deg_3',['v-carve_6mm_60deg',['../namespacev-carve__6mm__60deg.html',1,'']]]
];
