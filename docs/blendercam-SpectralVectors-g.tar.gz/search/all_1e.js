var searchData=
[
  ['👌_20features_0',['👌 Features',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md56',1,'']]]
];
