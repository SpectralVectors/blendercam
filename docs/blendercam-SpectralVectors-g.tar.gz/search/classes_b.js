var searchData=
[
  ['machinesettings_0',['machineSettings',['../classcam_1_1machine__settings_1_1machineSettings.html',1,'cam::machine_settings']]]
];
