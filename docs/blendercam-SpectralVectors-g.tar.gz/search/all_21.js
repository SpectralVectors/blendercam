var searchData=
[
  ['📒_20files_20organisation_0',['📒 Files Organisation',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md59',1,'']]]
];
