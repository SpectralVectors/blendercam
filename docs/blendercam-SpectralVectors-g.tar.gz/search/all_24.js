var searchData=
[
  ['🪪_20license_0',['🪪 License',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2README.html#autotoc_md64',1,'']]]
];
