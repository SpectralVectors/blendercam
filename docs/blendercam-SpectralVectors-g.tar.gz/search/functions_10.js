var searchData=
[
  ['quadrant_5fend_0',['quadrant_end',['../classcam_1_1nc_1_1heiden_1_1Creator.html#a405ea0a6ba05ccb794452267e759ca4e',1,'cam.nc.heiden.Creator.quadrant_end()'],['../classcam_1_1nc_1_1iso_1_1Creator.html#a827613cf1916273f770cf2ddcc5ee508',1,'cam.nc.iso.Creator.quadrant_end()']]],
  ['quadrant_5fstart_1',['quadrant_start',['../classcam_1_1nc_1_1heiden_1_1Creator.html#aa1397eef1123a98b8c1a29b95a0feca3',1,'cam.nc.heiden.Creator.quadrant_start()'],['../classcam_1_1nc_1_1iso_1_1Creator.html#aacc459d91d8bf1903156fa9974629267',1,'cam.nc.iso.Creator.quadrant_start()']]]
];
