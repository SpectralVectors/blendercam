var indexSectionsWithContent =
{
  0: "3_abcdefghijklmnopqrstuvwxyz•👁👌👨💻📒🤕🤝🪪",
  1: "abcdefghiklmnoprstuvw",
  2: "bcefgikprtv",
  3: "_abcdefghijklmnoprstuvw",
  4: "_abcdefghijlmnopqrstuvwxyz",
  5: "_abcdefghijklmnopqrstuvwxyz",
  6: "exy",
  7: "abdghioprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties",
  7: "Pages"
};

