var searchData=
[
  ['and_20pocket_20operations_0',['Profile and Pocket operations',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Profile_01and_01Pocket_01operations.html',1,'']]]
];
