var searchData=
[
  ['descriptions_0',['Blendercam Panel Descriptions',['../md__2tmp_2github__repos__arch__doc__gen_2SpectralVectors_2blendercam_2documentation_2Blendercam-Panel-Descriptions.html',1,'']]]
];
