var classcam_1_1ops_1_1CamOperationRemove =
[
    [ "execute", "classcam_1_1ops_1_1CamOperationRemove.html#aba9e2f29b70d8cd1aa5055ca30664efc", null ],
    [ "poll", "classcam_1_1ops_1_1CamOperationRemove.html#a2573da5234fe8712bdf8031c18e1b8b7", null ],
    [ "bl_idname", "classcam_1_1ops_1_1CamOperationRemove.html#a4f801818ce867baa7b8e7e637094f2c4", null ],
    [ "bl_label", "classcam_1_1ops_1_1CamOperationRemove.html#ac5d578cb341fbc392802bb2f098211dd", null ],
    [ "bl_options", "classcam_1_1ops_1_1CamOperationRemove.html#a9d2c0ac78fb11ff3d4cefe073b691ed6", null ]
];