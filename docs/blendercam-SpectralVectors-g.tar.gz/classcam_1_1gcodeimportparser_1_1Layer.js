var classcam_1_1gcodeimportparser_1_1Layer =
[
    [ "__init__", "classcam_1_1gcodeimportparser_1_1Layer.html#a7f7e58d5d8559af6bb7ea7091d226aef", null ],
    [ "__str__", "classcam_1_1gcodeimportparser_1_1Layer.html#a129d8c9548364499a6eccc1e9890329c", null ],
    [ "distance", "classcam_1_1gcodeimportparser_1_1Layer.html#a29275fbe625bc73d51a7a5207e8d2a02", null ],
    [ "extrudate", "classcam_1_1gcodeimportparser_1_1Layer.html#a128e44750c222cf2a0200fdbf6fbd9e2", null ],
    [ "segments", "classcam_1_1gcodeimportparser_1_1Layer.html#a94401e719268af526ee1a25c0a557c92", null ],
    [ "Z", "classcam_1_1gcodeimportparser_1_1Layer.html#a45d4abaca085e5b1ca4b94f0b93160aa", null ]
];