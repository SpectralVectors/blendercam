var namespacecam_1_1ui__panels_1_1operations =
[
    [ "CAM_OPERATIONS_Panel", "classcam_1_1ui__panels_1_1operations_1_1CAM__OPERATIONS__Panel.html", "classcam_1_1ui__panels_1_1operations_1_1CAM__OPERATIONS__Panel" ]
];