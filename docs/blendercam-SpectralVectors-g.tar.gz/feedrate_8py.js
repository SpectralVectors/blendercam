var feedrate_8py =
[
    [ "cam.ui_panels.feedrate.CAM_FEEDRATE_Panel", "classcam_1_1ui__panels_1_1feedrate_1_1CAM__FEEDRATE__Panel.html", "classcam_1_1ui__panels_1_1feedrate_1_1CAM__FEEDRATE__Panel" ]
];