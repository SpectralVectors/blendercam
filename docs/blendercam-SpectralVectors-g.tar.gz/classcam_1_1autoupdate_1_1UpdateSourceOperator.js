var classcam_1_1autoupdate_1_1UpdateSourceOperator =
[
    [ "execute", "classcam_1_1autoupdate_1_1UpdateSourceOperator.html#a46ef1de640e2121d7843f4a560e38af8", null ],
    [ "bl_idname", "classcam_1_1autoupdate_1_1UpdateSourceOperator.html#ab33486c49808c92b108bcf88f0538179", null ],
    [ "bl_label", "classcam_1_1autoupdate_1_1UpdateSourceOperator.html#a1dcd8e2bb9ee351921deed009631e814", null ],
    [ "new_source", "classcam_1_1autoupdate_1_1UpdateSourceOperator.html#aaf6e4d2cc9cb54c082ccf33c3a362fce", null ]
];