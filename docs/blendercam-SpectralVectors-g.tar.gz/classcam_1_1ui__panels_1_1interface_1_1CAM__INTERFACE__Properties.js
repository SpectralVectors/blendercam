var classcam_1_1ui__panels_1_1interface_1_1CAM__INTERFACE__Properties =
[
    [ "level", "classcam_1_1ui__panels_1_1interface_1_1CAM__INTERFACE__Properties.html#afd8eb7908c06b09bd47cc4c9df36acc2", null ]
];