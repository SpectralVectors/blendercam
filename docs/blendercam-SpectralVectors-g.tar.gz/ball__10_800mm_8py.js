var ball__10_800mm_8py =
[
    [ "cutter_diameter", "ball__10_800mm_8py.html#a573382cc74bd779f88cbd4d7079b8522", null ],
    [ "cutter_length", "ball__10_800mm_8py.html#ab2d208372d6e429c9fbb1815241cd1da", null ],
    [ "cutter_tip_angle", "ball__10_800mm_8py.html#aa68b47690620aadc62284638019046d4", null ],
    [ "cutter_type", "ball__10_800mm_8py.html#a71fdf530544bcdcb304d3b5e0e32a882", null ],
    [ "d", "ball__10_800mm_8py.html#a9d444e86ccfea5a05822cfd50a9d474c", null ]
];