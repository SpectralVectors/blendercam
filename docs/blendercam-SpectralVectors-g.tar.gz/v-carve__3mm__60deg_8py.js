var v_carve__3mm__60deg_8py =
[
    [ "cutter_diameter", "v-carve__3mm__60deg_8py.html#a737540b0fd9e6ee290e49257f4a11cf6", null ],
    [ "cutter_length", "v-carve__3mm__60deg_8py.html#a57cd9881a36564b4379ffe2abeb4e87b", null ],
    [ "cutter_tip_angle", "v-carve__3mm__60deg_8py.html#ac2b43963299215fb4e1c8c1c1b4ddcad", null ],
    [ "cutter_type", "v-carve__3mm__60deg_8py.html#af66423b759b5b20a4b29c6fdb722aef7", null ],
    [ "d", "v-carve__3mm__60deg_8py.html#aade13dac6bc62e578c30977fd516e3e9", null ]
];