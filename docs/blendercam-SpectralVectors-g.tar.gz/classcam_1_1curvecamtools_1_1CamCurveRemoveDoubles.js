var classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles =
[
    [ "draw", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#a9c66e9e9aac12b5296e0fd7a72b00b9b", null ],
    [ "execute", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#a74293880d3636576b99bd28482d5267d", null ],
    [ "invoke", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#a72e441051132a13daa4c72bff5264664", null ],
    [ "poll", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#a8fe1fcebd1de6f340b551e19effbb47b", null ],
    [ "bl_idname", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#af691bcadefe97c58964a5d388f2af334", null ],
    [ "bl_label", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#a3a0aa51b936dea66f14a8e6429b1502b", null ],
    [ "bl_options", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#abc88d3f6b1d907423bae12d5999f5c90", null ],
    [ "keep_bezier", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#afff7b4ffb774d70a14790abb24f8901a", null ],
    [ "merg_distance", "classcam_1_1curvecamtools_1_1CamCurveRemoveDoubles.html#ab92eac322df9df65560f9ab7ebca00a1", null ]
];