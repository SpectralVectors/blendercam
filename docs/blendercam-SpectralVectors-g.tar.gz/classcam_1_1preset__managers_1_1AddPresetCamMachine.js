var classcam_1_1preset__managers_1_1AddPresetCamMachine =
[
    [ "bl_idname", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#ac1c708789b4f96b917499354a32c3f94", null ],
    [ "bl_label", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#a47154ef591a14abd6d942277974c69c8", null ],
    [ "preset_defines", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#a5c4514bf7f0c2ee7b45efec33a8bc573", null ],
    [ "preset_menu", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#a7ce33c6e0794b1614c151f7483d71335", null ],
    [ "preset_subdir", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#a0d38dced816ccb66109d1dc7fd4a144c", null ],
    [ "preset_values", "classcam_1_1preset__managers_1_1AddPresetCamMachine.html#ab17ccff2cf9b96db7ecdfad4a005d2d7", null ]
];