var namespacecam_1_1slice =
[
    [ "SliceObjectsSettings", "classcam_1_1slice_1_1SliceObjectsSettings.html", "classcam_1_1slice_1_1SliceObjectsSettings" ],
    [ "sliceObject", "namespacecam_1_1slice.html#a30350e381a415468a866fd20161f0fb6", null ],
    [ "slicing2d", "namespacecam_1_1slice.html#a6831dd1c7835cc7f0affc4109792fda6", null ],
    [ "slicing3d", "namespacecam_1_1slice.html#ac6beb7cb6839830b3c8aeaebffb12c09", null ]
];