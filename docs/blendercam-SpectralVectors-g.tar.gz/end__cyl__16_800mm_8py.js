var end__cyl__16_800mm_8py =
[
    [ "cutter_diameter", "end__cyl__16_800mm_8py.html#a798c30f2af617f6c99ddaef649d8d5d4", null ],
    [ "cutter_length", "end__cyl__16_800mm_8py.html#ab787295b2df2229b83e5b1ec4740e516", null ],
    [ "cutter_tip_angle", "end__cyl__16_800mm_8py.html#a6d6d602bffe36e15d5f2c8bf0aba39cb", null ],
    [ "cutter_type", "end__cyl__16_800mm_8py.html#a9011cefc8b35f3301320035d512db7e2", null ],
    [ "d", "end__cyl__16_800mm_8py.html#a3dbb1b311f382e6c98150a36866dd611", null ]
];