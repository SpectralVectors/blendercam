var namespacepie__optimisation =
[
    [ "VIEW3D_MT_PIE_Optimisation", "classpie__optimisation_1_1VIEW3D__MT__PIE__Optimisation.html", "classpie__optimisation_1_1VIEW3D__MT__PIE__Optimisation" ]
];