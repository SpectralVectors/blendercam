var ball__20_800mm_8py =
[
    [ "cutter_diameter", "ball__20_800mm_8py.html#a2f5b183c1518f1bb161398e4e7da6a07", null ],
    [ "cutter_length", "ball__20_800mm_8py.html#a793564213e9b889c7c15dc0ae7006719", null ],
    [ "cutter_tip_angle", "ball__20_800mm_8py.html#aed34c7aa385f127c4738b45bef4245e0", null ],
    [ "cutter_type", "ball__20_800mm_8py.html#aa08cbe82c849e1097d37338c7441e2ec", null ],
    [ "d", "ball__20_800mm_8py.html#a2591d4e09c9dabbfbdee00873e7eb232", null ]
];