var ball__8_800mm_8py =
[
    [ "cutter_diameter", "ball__8_800mm_8py.html#a9c054c291fb244262981626d957285b3", null ],
    [ "cutter_length", "ball__8_800mm_8py.html#ac54ea5ba7194fb974c959d2e2054000e", null ],
    [ "cutter_tip_angle", "ball__8_800mm_8py.html#a82e031a437b4cde20b93c410803b058e", null ],
    [ "cutter_type", "ball__8_800mm_8py.html#a4b391d8e5154a4a5fd4ff2e97a84779d", null ],
    [ "d", "ball__8_800mm_8py.html#a7e741afce69ac820f690b1b149ff6a0e", null ]
];