var classcam_1_1ops_1_1CamOperationCopy =
[
    [ "execute", "classcam_1_1ops_1_1CamOperationCopy.html#a8f65c77a65264f8f6f7de292b19e647c", null ],
    [ "poll", "classcam_1_1ops_1_1CamOperationCopy.html#a2e68860d7f8805f774f2b6838b887da1", null ],
    [ "bl_idname", "classcam_1_1ops_1_1CamOperationCopy.html#a95129a506947ae29ec8fa941a4bc72ad", null ],
    [ "bl_label", "classcam_1_1ops_1_1CamOperationCopy.html#ad56bac548ffbc67dd6f74b9682a45e4d", null ],
    [ "bl_options", "classcam_1_1ops_1_1CamOperationCopy.html#a33fcfb805c3fd266bffe3fdb73e6ee5f", null ]
];