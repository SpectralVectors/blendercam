var classcam_1_1ops_1_1CamOperationAdd =
[
    [ "execute", "classcam_1_1ops_1_1CamOperationAdd.html#aa91e31ea746da1de655e3a6ef52d4567", null ],
    [ "poll", "classcam_1_1ops_1_1CamOperationAdd.html#ac2e9c5045f27916dcf82907d21b48dad", null ],
    [ "bl_idname", "classcam_1_1ops_1_1CamOperationAdd.html#ab2f62f64e0169226950ae1b7bbd572f6", null ],
    [ "bl_label", "classcam_1_1ops_1_1CamOperationAdd.html#a8d07c075dd48ddf255931541b5795cc1", null ],
    [ "bl_options", "classcam_1_1ops_1_1CamOperationAdd.html#a87b89e253f1385f1c17f7fb65d23bd46", null ]
];