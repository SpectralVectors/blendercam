var classcam_1_1preset__managers_1_1AddPresetCamOperation =
[
    [ "bl_idname", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#a6066f3df5b776d5032f3e4fed6a10922", null ],
    [ "bl_label", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#ac176486e1fbe07dad2265d4f9f944cc3", null ],
    [ "preset_defines", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#ab67d60a91b10228d459b0c3bec4bd823", null ],
    [ "preset_menu", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#a4d93b37ff923625bcaebb986b9ffab3a", null ],
    [ "preset_subdir", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#a482e1eacc3fc56ce9e704c352dcf37fc", null ],
    [ "preset_values", "classcam_1_1preset__managers_1_1AddPresetCamOperation.html#af58db1dfce679316710dbc2ef07cbc70", null ]
];