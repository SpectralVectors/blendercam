var classcam_1_1ops_1_1threadCom =
[
    [ "__init__", "classcam_1_1ops_1_1threadCom.html#ac20e7ab7be56a8a6ee2438294888908a", null ],
    [ "lasttext", "classcam_1_1ops_1_1threadCom.html#a8c5c79d7586716b2f20003e4cecb2b1c", null ],
    [ "opname", "classcam_1_1ops_1_1threadCom.html#aabcc823417229a210adca44ba47734a2", null ],
    [ "outtext", "classcam_1_1ops_1_1threadCom.html#a34419a7f92b0b1a1ca25c5c28c336d55", null ],
    [ "proc", "classcam_1_1ops_1_1threadCom.html#ae4251d346787c48450d0a9dcb2a62749", null ]
];