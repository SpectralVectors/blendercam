var namespacepie__area =
[
    [ "VIEW3D_MT_PIE_Area", "classpie__area_1_1VIEW3D__MT__PIE__Area.html", "classpie__area_1_1VIEW3D__MT__PIE__Area" ]
];