var end__cyl__4_800mm_8py =
[
    [ "cutter_diameter", "end__cyl__4_800mm_8py.html#ab81d5c002e310d86310f1e9ef34d10d4", null ],
    [ "cutter_length", "end__cyl__4_800mm_8py.html#ae4d18cf41ab2ee2c2a517c9301493ab4", null ],
    [ "cutter_tip_angle", "end__cyl__4_800mm_8py.html#a56935088d327e2b2973edc7fe200d559", null ],
    [ "cutter_type", "end__cyl__4_800mm_8py.html#a495257631c0f5729b459fabd2c38f71c", null ],
    [ "d", "end__cyl__4_800mm_8py.html#a80a973a2b245e0a07058107be6c99441", null ]
];