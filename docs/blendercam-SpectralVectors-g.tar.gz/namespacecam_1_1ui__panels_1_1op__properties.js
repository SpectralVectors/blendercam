var namespacecam_1_1ui__panels_1_1op__properties =
[
    [ "CAM_OPERATION_PROPERTIES_Panel", "classcam_1_1ui__panels_1_1op__properties_1_1CAM__OPERATION__PROPERTIES__Panel.html", "classcam_1_1ui__panels_1_1op__properties_1_1CAM__OPERATION__PROPERTIES__Panel" ]
];