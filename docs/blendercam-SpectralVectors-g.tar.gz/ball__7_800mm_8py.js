var ball__7_800mm_8py =
[
    [ "cutter_diameter", "ball__7_800mm_8py.html#a8f1f3fc572b8d57083c5a0c508c4e642", null ],
    [ "cutter_length", "ball__7_800mm_8py.html#a912a4d10771ef601baa514716ed75261", null ],
    [ "cutter_tip_angle", "ball__7_800mm_8py.html#a03216601ba499142eb6cf38407886b98", null ],
    [ "cutter_type", "ball__7_800mm_8py.html#a174078b483d9aa68da604801954ebded", null ],
    [ "d", "ball__7_800mm_8py.html#a023a36c474d1c359b1b8639d8ba10db4", null ]
];