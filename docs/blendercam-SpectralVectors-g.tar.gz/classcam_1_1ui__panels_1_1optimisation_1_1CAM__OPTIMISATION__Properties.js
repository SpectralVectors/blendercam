var classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties =
[
    [ "circle_detail", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a6866f5c2118f033990bf5fa26d957e3c", null ],
    [ "exact_subdivide_edges", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a3bbee1eaa0dc2685a14ecbc5c624d0ac", null ],
    [ "imgres_limit", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a4972668f6ed2013b6083fe832c1735dc", null ],
    [ "optimize", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a4a0bb7b3bc5aaefad3ef5f9620a9532f", null ],
    [ "optimize_threshold", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a423f20d8152d97c4ffee5001591bd6c0", null ],
    [ "pixsize", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a43fb6dc2ddede5c06d3565cb119a0691", null ],
    [ "simulation_detail", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a9b35fede09dd4ac8ad30cc1aa81c6d76", null ],
    [ "use_exact", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a6efca41a173bb6bc9b01b0c671913e10", null ],
    [ "use_opencamlib", "classcam_1_1ui__panels_1_1optimisation_1_1CAM__OPTIMISATION__Properties.html#a93bcf16753365164737a0aa6e8d692ad", null ]
];