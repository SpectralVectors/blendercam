var classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties =
[
    [ "free_height", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a750132340fc74b60b7fad711cce93d95", null ],
    [ "G64", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a1795d9c99926d318c3a9a03df58be439", null ],
    [ "helix_diameter", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a7875ed4d9823ba6e69dda7f35b0e8a1f", null ],
    [ "helix_enter", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#abd31ed7179be38cf1b4cf92fa092273e", null ],
    [ "insideout", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#abe9a49d6ac58a174aeb5306120507809", null ],
    [ "merge_dist", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a6f4af4226d5b86aef80244b5830cbde4", null ],
    [ "parallel_step_back", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a5e0ec9058f6e9d786cdf726116d37135", null ],
    [ "protect_vertical", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#ad88247e9273a35214aca85482639fc3a", null ],
    [ "protect_vertical_limit", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#aafbf665c1098158dced78e9da6b2f3dd", null ],
    [ "ramp", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#afb51651371c3b660fc2656d8ff099514", null ],
    [ "ramp_in_angle", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#ae4ceece6cf1e07d2072e96c27eb18f6a", null ],
    [ "ramp_out", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#aa4b7884b2212a22882958799ce41ae07", null ],
    [ "ramp_out_angle", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#ab34d4f58abf832705a67c4930e07bed4", null ],
    [ "retract_height", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a192d1a4e6f9328c5664c246e7cca6d93", null ],
    [ "retract_radius", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#ae17f3662b1910542696c4a5dddc1a6f6", null ],
    [ "retract_tangential", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#aed044498dd510a34ca599e3a4617c335", null ],
    [ "spindle_rotation", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#ac7780fc216a7405cd97d188a6e04040f", null ],
    [ "stay_low", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#aa50684e57c8598a613df844cbb6f48a8", null ],
    [ "type", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a91ad11dcdba79afd09a66b4e0d9010fb", null ],
    [ "useG64", "classcam_1_1ui__panels_1_1movement_1_1CAM__MOVEMENT__Properties.html#a2194c316793cdd6401799db16f20e6ea", null ]
];