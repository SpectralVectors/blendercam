var classcam_1_1ui__panels_1_1info_1_1CAM__INFO__Properties =
[
    [ "chipload", "classcam_1_1ui__panels_1_1info_1_1CAM__INFO__Properties.html#a5f862844dea04cf41b3fd960560a2525", null ],
    [ "duration", "classcam_1_1ui__panels_1_1info_1_1CAM__INFO__Properties.html#ac4e59879260a5738fa39bd399aa200e0", null ],
    [ "warnings", "classcam_1_1ui__panels_1_1info_1_1CAM__INFO__Properties.html#a7cb22ffb531b0c4fe719b5c547db715e", null ]
];